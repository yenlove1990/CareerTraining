package com.example.demo.Entity;

import lombok.Data;

@Data
public class Document {

    private int id;
    private String content;

}
